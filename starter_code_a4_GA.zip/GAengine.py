import random
from Utils import Chromosome, Food

class GAEngine:
    
    def __init__(self):
        self.population = []
        self.food = []
        self.generations = 0

    def make_initial_population(self, population_size):       
        for i in range(population_size):
            self.population.append(Chromosome(random.randint(0, 790), random.randint(0, 590)))

    def add_food(self, no_of_food):     
        for i in range(no_of_food):
            self.food.append(Food(random.randint(0, 790), random.randint(0, 590)))

    # selection code goes here...
    def do_crossover(self, no_of_offspring):
        pass

    # fitness calculation goes here...
    def assign_fitness(self):
        return 0

    def get_population(self):
        return self.population

    def get_foods(self):
        return self.food