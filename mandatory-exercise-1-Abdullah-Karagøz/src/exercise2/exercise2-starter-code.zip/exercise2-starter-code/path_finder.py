from utils import duckietown, visualize_path

def minimum_battery_consumption(grid):

    # TODO: find out the minimum percentage of battery needed to reach the charging station 
    # if the value at grid[i][j] is negative then it is an obstacle
    # otherwise it is the battery consumption (in percentage) required to traverse the cell
    # the starting position for Donald is grid[0][0] and the goal position is grid[height-1][width-1]
    pass



def least_battery_consuming_path(grid, cost):

    # TODO: find the optimal sequence of actions {'East', 'South'} to reach the charging station
    path = ['East','East','South']
    return path
    
    
if __name__ == '__main__':

    # properties of the grid
    height = 30
    width = 50
    obstacles_file = 'obstacles.txt'


    # constructs the grid and initializes cell values
    grid = duckietown(height, width, obstacles_file)
    
    # path finding algorithm using dynamic programming
    cost = minimum_battery_consumption(grid)
    path = least_battery_consuming_path(grid, cost)

    # sets the speed of Donald to a number between 1 and 10 (fastest = 10)
    donald_speed = 1

    # visualizes the path
    visualize_path(grid, path, donald_speed)
